﻿import logging
import ResultFolder

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def CreateLoggerFile(filename):
    try:
        fulllogname = ResultFolder.GetRunDirectory()+"\\"+filename+".log"
        fh = logging.FileHandler(fulllogname)
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s [line:%(lineno)d] %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    except Exception as err:
        logger.debug("Error when creating log file, error message: {}".format(str(err)))


def Log(message):
    logger.debug(message)

#logging.basicConfig(level=logging.DEBUG,
#            format='%(asctime)s [line:%(lineno)d] %(message)s',
#            datefmt='%a, %d %b %Y %H:%M:%S',
#            filename=ResultFolder.GetRunDirectory()+"\\TestCaseExecutionLog.log",
#            filemode='w')
#global logger
#fulllogname = ResultFolder.GetRunDirectory()+"\\test.log"
#fh = logging.FileHandler(fulllogname)
#fh.setLevel(logging.DEBUG)
#formatter = logging.Formatter('%(asctime)s [line:%(lineno)d] %(message)s')
#fh.setFormatter(formatter)
#logger.addHandler(fh)
#fh = logging.FileHandler()
#class LogUtility(object):
#    def __init__(self,logname):    
#        logging.basicConfig(level=logging.DEBUG,
#                format='%(asctime)s [line:%(lineno)d] %(message)s',
#                datefmt='%a, %d %b %Y %H:%M:%S',
#                filename="test.log",
#                filemode='w')
#    def Log(self, message):
#        logging.info(message)
