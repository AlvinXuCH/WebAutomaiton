import ResultFolder
import logging
from LogUtility import LogUtility
import subprocess
from datetime import datetime
def CreateRunFolder():
    time = datetime.now()
    subprocess.call("mkdir TestRun_"+time.strftime("%Y_%m_%d_%H_%M_%S"),shell=True)

if __name__ == "__main__":
    #print(ResultFolder.GetRunDirectory())
    logname = "test1"
    CreateRunFolder()
    log = LogUtility(logname)
    log.Log("this is a test")

    #logging.basicConfig(level=logging.DEBUG,
    #            format='%(asctime)s [line:%(lineno)d] %(message)s',
    #            datefmt='%a, %d %b %Y %H:%M:%S',
    #            filename=ResultFolder.GetRunDirectory()+"\\"+logname+'.log',
    #            filemode='w')

    #logging.info("This is a Test")