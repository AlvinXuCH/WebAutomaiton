﻿from BasePage import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

class FloorManagerLiteMain(BasePage):
    """description of class"""
    allFeaturesTab = (By.ID,'all-features-tab')

    tabSpans = (By.XPATH,'//span[@class="k-link k-header"]')

    subSpans = (By.XPATH,'//a[@data-ui-sref="performance_status"][@href="/system_monitor"]')

    tableRows = (By.XPATH,'//tr[@class="ng-scope"]')

    editPanel = (By.CSS_SELECTOR,'input[ng-model="selectedRole.roleName"]')

    totalRow = (By.XPATH,'//*[@id="content"]/div/div[1]/table/tfoot/tr/td[1]/a')
    

    def openAllFeaturesTab(self):
        allFeatures = self.driver.find_element(*FloorManagerLiteMain.allFeaturesTab)
        allFeatures.click()

    def findSecuritySpan(self):
        spans = self.driver.find_elements(*FloorManagerLiteMain.tabSpans)
        for span in spans:
            if span.text == "System Diagnostic":
                span.click()

    def findSubTabAndClick(self):
        rolesAndPermission = self.driver.find_element(*FloorManagerLiteMain.subSpans)
        rolesAndPermission.click()

    def findTotal(self):
        onlineTotal = self.driver.find_element(*FloorManagerLiteMain.totalRow)
        return onlineTotal.text


    def findRowsAndEdit(self):
        rows = self.driver.find_elements(*FloorManagerLiteMain.tableRows)
        for row in rows:
            children = row.find_elements_by_css_selector("*")
            if(children[0].text == "Accounting Manager"):
                children[3].click()
                break

    def editRoleDescription(self):
        descriptionTextBox = self.driver.find_element(*FloorManagerLiteMain.editPanel)
        self.driver.execute_script("alert(\"this is a test\");",descriptionTextBox)
        text = descriptionTextBox.get_attribute("value")
        descriptionTextBox.clear()
        descriptionTextBox.send_keys("Alvin"+Keys.RETURN)


    
    def findRoleInSecurityRoleListByName(self,roleName):
        rows = self.driver.find_elements(*FloorManagerLiteMain.tableRows)
        for row in rows:
            children = row.find_elements_by_css_selector("*")
            if(children[0].text == roleName):
                return row

    roleNameInput = (By.XPATH,'//input[@placeholder="Role name"]')
    def editRole(self,roleName):
        row = FloorManagerLiteMain.findRoleInSecurityRoleListByName(self,roleName)
        children = row.find_elements_by_css_selector("*")
        children[3].click()
        roleInput = self.driver.find_element(*FloorManagerLiteMain.roleNameInput)
        wait = WebDriverWait(self.driver, 20)
        role_name = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR,'input[ng-model="selectedRole.roleName"]')))

#now go for set value
        role_name.send_keys("alvin")
        #roleInput.send_keys("test")
        #self.driver.execute_script("alert(\"this is a test\");",roleInput)
        ##self.driver.execute_script('arguments[0].click();");',roleInput)
        self.driver.execute_script('arguments[0].setAttribute("value","alvin");',roleInput)
        #self.driver.execute_script('arguments[0].focus();',roleInput)
        ##self.driver.execute_script('angular.element(arguments[0]).click().;',roleInput)
        #self.driver.execute_script('$(arguments[0]).click().;',roleInput)






