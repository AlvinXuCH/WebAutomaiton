﻿class BasePage(object):
    """description of class"""

    #webdriver instance
    def __init__(self, driver):
        self.driver = driver

