﻿import unittest
from selenium import webdriver
from GoogleMainPage import GoogleMainPage
import CommonConfiguration
from TestCaseInfo import TestCaseInfo
from TestReport import TestReport
from datetime import datetime
import LogUtility
import time

class Test_TC_SearchPython(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome(CommonConfiguration.driverPath())
        self.base_url = CommonConfiguration.baseUrl()
        self.testCaseInfo = TestCaseInfo(id=1,name="Test google search python",owner='xua')
        self.testResult = TestReport()
        time.sleep(3)
        LogUtility.CreateLoggerFile("Test_TC_SearchPython")
    def test_A(self):
        try:

            self.testCaseInfo.starttime = datetime.now()
            LogUtility.Log("test")
            #LogUtility.Log("Open base page www.google.com")
            #self.driver.get(self.base_url)
            #currentPage = GoogleMainPage(self.driver)
            #LogUtility.Log("Type python in search box")
            #currentPage.inputSearchContent("python")
            self.testCaseInfo.result = "Pass"
        except Exception as err:
            self.testCaseInfo.errorinfo = str(err)
            #self.log.Log("Got error: "+str(err))
        finally:
            self.testCaseInfo.endtime = datetime.now()
            self.testCaseInfo.secondsDuration = (self.testCaseInfo.endtime - self.testCaseInfo.starttime).seconds

    def tearDown(self):
        self.driver.close()
        self.testResult.WriteHTML(self.testCaseInfo)


if __name__ == '__main__':
    #LogUtility("Test_TC_SearchPython")
    unittest.main()
